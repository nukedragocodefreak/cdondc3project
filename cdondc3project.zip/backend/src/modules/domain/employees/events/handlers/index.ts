import { NotifyEmployeeCreatedConsole } from './notify-employee-created-console.handler';

export const EventHandlers = [NotifyEmployeeCreatedConsole];
